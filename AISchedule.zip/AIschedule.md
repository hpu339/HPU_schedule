##If you have any questions, please use the following contact methods to discuss:
#####NetEase_email:15513924345@163.com
#####QQ_email:1639446186@qq.com
#####Google_email:1810ylx@gmail.com
#####Microsoft_email:Y15513924345@Outlook.com
#####QQ:1639446186
#####CSDN:hpuylx

####1.The ‘’scheduleHtmlParser.js’’ and ‘’scheduleHtmlProvider.js’’ in the js file are files to be edited
####2.Link to the official document of the Xiao Ai class schedule: https://ldtu0m3md0.feishu.cn/docs/doccnhZPl8KnswEthRXUz8ivnhb
####3.And you can learn more about the content by searching the account on csdn
